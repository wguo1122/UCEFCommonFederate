#!/bin/bash
find */build.sh -maxdepth 1 -execdir sh {} \;


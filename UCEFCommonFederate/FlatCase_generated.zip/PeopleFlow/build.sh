#!/bin/bash
mvn clean install -U

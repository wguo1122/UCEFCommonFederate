#!/bin/bash
mvn clean install
mvn package -P CppFed

